import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

import org.graalvm.compiler.lir.alloc.lsra.LinearScan;

public class Test {

	public static void main(String[] args) {
		
		Scanner sc = null;
	    Scanner sc1 = null;
		
	
		Scanner keyboard = new Scanner(System.in);
		
		
		TvShow show = new TvShow ("cbc20","yoyo",21.30,22.30);
		TvShow showy = new TvShow("cbc20","yoyo",21.00,21.00);
		
		show.isOntime(showy);
			
			
		
		
		

			
			

		
			
	
		
		


	}

}
